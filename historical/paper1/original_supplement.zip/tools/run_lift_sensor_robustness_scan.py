"""Measurement-perturbation audit for the paper-1 lift virtual prototype."""
from __future__ import annotations

import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).parents[1]
sys.path[:0] = [str(ROOT / "code"), str(ROOT / "code" / "lift_control")]

from experiments import ExperimentConfig, run_definition

SEEDS = tuple(range(2026, 2046))
CASES = {
    "nominal": {},
    "position_bias_plus_2mm": {"position_sensor_bias_m": 0.002},
    "position_bias_minus_2mm": {"position_sensor_bias_m": -0.002},
    "pressure_bias_plus_0p1MPa": {"pressure_measurement_bias_pa": 0.1e6},
    "pressure_bias_minus_0p1MPa": {"pressure_measurement_bias_pa": -0.1e6},
    "pressure_noise_0p1MPa": {"pressure_measurement_noise_std_pa": 0.1e6},
    "combined_pos_plus_2mm_pressure_plus_0p1MPa": {
        "position_sensor_bias_m": 0.002,
        "pressure_measurement_bias_pa": 0.1e6,
    },
}


def mean_ci(values: list[float]) -> dict[str, float]:
    mean = sum(values) / len(values)
    std = (sum((value - mean) ** 2 for value in values) / (len(values) - 1)) ** 0.5
    half = 2.093 * std / math.sqrt(len(values))
    return {"n": len(values), "mean": mean, "std": std,
            "ci95_low": mean - half, "ci95_high": mean + half}


def summarize(rows: list[dict[str, object]]) -> dict[str, object]:
    drops = [float(row["hold_drop_m"]) for row in rows if row["hold_drop_m"] is not None]
    max_errors = [float(row["steady_max_abs_error_m"]) for row in rows]
    return {
        "hold_entry_rate": sum(bool(row["hold_started"]) for row in rows) / len(rows),
        "steady_rmse_mm": mean_ci([float(row["steady_rmse_m"]) * 1000.0 for row in rows]),
        "steady_p95_abs_error_mm": mean_ci([float(row["steady_p95_abs_error_m"]) * 1000.0 for row in rows]),
        "steady_max_abs_error_mm": mean_ci([value * 1000.0 for value in max_errors]),
        "worst_steady_max_abs_error_mm": max_errors and max(max_errors) * 1000.0,
        "hold_drop_mm": mean_ci([value * 1000.0 for value in drops]) if drops else None,
        "worst_hold_drop_mm": max(drops) * 1000.0 if drops else None,
        "observer_confidence_min": min(float(row["observer_confidence_min"]) for row in rows),
    }


def main() -> None:
    output: dict[str, object] = {
        "seeds": list(SEEDS),
        "protocol": {
            "duration_s": 1800.0,
            "reference_m": 0.35,
            "note": "Independent measurement-robustness audit of the theoretical virtual prototype; perturbations are not calibration data.",
            "hold_drop_threshold_mm": 10.0,
        },
        "cases": {},
    }
    for name, overrides in CASES.items():
        rows = []
        for seed in SEEDS:
            result = run_definition("hybrid", ExperimentConfig(**overrides), seed=seed)
            rows.append({
                "seed": seed,
                "hold_started": bool(result["hold_started"]),
                "hold_drop_m": result["hold_drop_m"],
                "steady_rmse_m": float(result["steady_rmse_m"]),
                "steady_p95_abs_error_m": float(result["steady_p95_abs_error_m"]),
                "steady_max_abs_error_m": float(result["steady_max_abs_error_m"]),
                "settling_error_m": float(result["settling_error_m"]),
                "observer_confidence_min": float(result["observer_confidence_min"]),
            })
            print(name, seed, flush=True)
        output["cases"][name] = {"overrides": overrides, "rows": rows,
                                  "summary": summarize(rows)}
    path = ROOT / "results" / "lift_sensor_robustness_scan.json"
    path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()
