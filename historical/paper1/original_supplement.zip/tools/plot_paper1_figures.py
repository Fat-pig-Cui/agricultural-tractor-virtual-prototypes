#!/usr/bin/env python3
"""Regenerate the Paper 1 figures from the frozen result files."""
from plot_submission_figures import lift_figures
from plot_v2_submission_figures import architecture_paper1, results_paper1


if __name__ == "__main__":
    lift_figures()
    architecture_paper1()
    results_paper1()
